# Requirements

jre 1.8

# Above All

- 用浏览器登录Sakai
- 选择`我的工作空间`-`用户偏好`
- 把需要用到的站点拖到靠左的一栏（显示在顶部导航栏）
- 点击下方`更新偏好`
- （Sakai语言选项使用中文）

# Usage

用记事本打开`congfig.properties`，设置账户信息

双击运行jar文件
